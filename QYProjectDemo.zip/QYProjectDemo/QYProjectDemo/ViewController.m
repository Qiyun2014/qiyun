//
//  ViewController.m
//  QYProjectDemo
//
//  Created by qiyun on 15/7/9.
//  Copyright (c) 2015年 com.application.qiyun. All rights reserved.
//

#import "ViewController.h"
#import "PublicViewModel.h"
#import "ViewModelClass.h"
#import "ViewControllerTableViewCell.h"
#import "JKColor+RGB.h"

@interface ViewController ()

{
    NSString    *name;
}

@property (nonatomic,strong) UITableView   *_tableView;

@property (nonatomic,strong) NSArray *dateArray;

@end

@implementation ViewController

- (id)init{

    self = [super init];

    if (self) {

        name = @"i am a bird !!!";
    }
    return self;
}

- (NSMethodSignature *)methodSignatureForSelector:(SEL)aSelector{

    NSMethodSignature *methodSignature = [super methodSignatureForSelector:aSelector];

    if (!methodSignature) {

        methodSignature = [name methodSignatureForSelector:aSelector];
    }

    for (NSInteger i = 0; i < [methodSignature numberOfArguments]; i ++) {

        NSLog(@"Argument  == %s",[methodSignature getArgumentTypeAtIndex:i]);
    }

    NSLog(@"returnType:%s ,returnLen:%lu" , [methodSignature methodReturnType] , (unsigned long)[methodSignature methodReturnLength]);
    NSLog(@"signature:%@" , methodSignature);
    return methodSignature;
}

- (void)forwardInvocation:(NSInvocation *)anInvocation
{
    NSLog(@"forwardInvocation:%@" , anInvocation);

    SEL seletor = [anInvocation selector];

    if ([name respondsToSelector:seletor]) {

        [anInvocation invokeWithTarget:name];
    }
    
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    id bird = [[ViewController alloc] init];
    NSLog(@"len= %lu", (unsigned long)[bird length]);

    self._tableView = [[UITableView alloc] initWithFrame:CGRectInset(self.view.frame, 20, 20)
                                                   style:UITableViewStylePlain];
    self._tableView.delegate = self;
    self._tableView.dataSource = self;
    [self.view addSubview:self._tableView];

    PublicViewModel  *modelClass = [[PublicViewModel alloc] init];
    [modelClass valueBlockReturn:^(id success) {

        _dateArray = (NSArray *)success;
        NSLog(@"success (VC) = %@",_dateArray[0]);

        //一定要刷新表视图，否则不执行delegate方法
        [self._tableView reloadData];

    } requestFaild:^(id faild) {

        NSLog(@"faild = %@",faild);

    } requestError:^(id error) {

        NSLog(@"error = %@",error);
    }];

    [modelClass fetchRequestOfResponseResult];

    /*!
     NSLog(@"CGRectGetMaxX   %f",CGRectGetMaxX(self.view.frame));   //宽度
     NSLog(@"CGRectGetMidX   %f",CGRectGetMidX(self.view.frame));   //宽度/2
     NSLog(@"CGRectGetMinX   %f",CGRectGetMinX(self.view.frame));   //最小宽度
     NSLog(@"CGRectGetMinY   %f",CGRectGetMinY(self.view.frame));   //最小高度
     NSLog(@"CGRectGetMaxY   %f",CGRectGetMaxY(self.view.frame));   //高度
     NSLog(@"CGRectInset  %@",NSStringFromCGRect(CGRectInset(self.view.frame, 20, 20)));
     */

    NSString    *str = @"123456 abcd";
    NSLog(@"%@",[str myLowerString]);
}

#pragma mark  ------------UITableView Delegate and Datasource

//设置每组多少行
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return _dateArray.count;
}

//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return 44;
}

//配置cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    static  NSString    *cellIdentifier = @"ViewControllerTableViewCell";

    ViewControllerTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];

    if (!cell) {

        cell = [[NSBundle mainBundle] loadNibNamed:cellIdentifier owner:nil options:nil][0];
    }

    [cell setElementsDataFromModel:_dateArray[indexPath.row]];
    
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
