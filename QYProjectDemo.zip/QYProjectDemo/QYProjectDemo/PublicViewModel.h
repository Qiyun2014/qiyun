//
//  PublicViewModel.h
//  QYProjectDemo
//
//  Created by qiyun on 15/7/10.
//  Copyright (c) 2015年 com.application.qiyun. All rights reserved.
//

#import "ViewModelClass.h"
#import "ViewControllerModel.h"
#import <CommonCrypto/CommonDigest.h>

@interface PublicViewModel : ViewModelClass

//网络请求
- (void)fetchRequestOfResponseResult;



@end
