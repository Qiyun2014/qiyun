//
//  JKFTPManager.m
//  QYProjectDemo
//
//  Created by qiyun on 15/7/16.
//  Copyright (c) 2015年 com.application.qiyun. All rights reserved.
//

#import "JKFTPManager.h"

@implementation JKFTPManager

- (id)initWithServer:(NSString *)server user:(NSString *)userName password:(NSString *)passWord{

    self = [super init];

    if (self) {


    }
    return self;
}

@end
