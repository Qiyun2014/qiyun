//
//  JKCommonClass.h
//  QYProjectDemo
//
//  Created by qiyun on 15/7/15.
//  Copyright (c) 2015年 com.application.qiyun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JKCommonClass : UIColor

@end