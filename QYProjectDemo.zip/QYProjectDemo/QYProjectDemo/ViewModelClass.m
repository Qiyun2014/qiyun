//
//  ViewModelClass.m
//  QYProjectDemo
//
//  Created by qiyun on 15/7/10.
//  Copyright (c) 2015年 com.application.qiyun. All rights reserved.
//

#import "ViewModelClass.h"
#import "JKRequestClass.h"

@implementation ViewModelClass

//网络状态
- (void)netWorkStatuWithServerConnect:(NetWorkBlock)netConnectBlock
                        withURLString:(NSString *)urlString{

    netConnectBlock([JKRequestClass netWorkReachabilityWithURLString:urlString]);
}

// 传入交互的Block块
- (void)valueBlockReturn:(requestSuccess)success
            requestFaild:(requestFaild)faild
            requestError:(requestError)error{

    _success = success;
    _faild = faild;
    _error = error;
}

@end
