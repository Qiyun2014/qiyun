//
//  ViewController.h
//  QYProjectDemo
//
//  Created by qiyun on 15/7/9.
//  Copyright (c) 2015年 com.application.qiyun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NSString(QYString)

- (NSString *)myLowerString;

@end

@implementation NSString (QYString)

- (NSString *)myLowerString{

    NSString *lowerString = [self uppercaseString];
    NSLog(@"%@ = 》  %@",self,lowerString);

    return lowerString;
}

@end


@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>


@end

