//
//  JKRequestClass.h
//  QYProjectDemo
//
//  Created by qiyun on 15/7/17.
//  Copyright (c) 2015年 com.application.qiyun. All rights reserved.
//

//请求成功
typedef void (^requestSuccess) (id success);

//请求失败
typedef void (^requestFaild) (id faild);

//请求错误（网络异常）
typedef void (^requestError) (id error);

#import <Foundation/Foundation.h>
#import <AFNetworking/AFNetworking.h>

@interface JKRequestClass : NSObject


//post请求
+ (void)netPostRequestServerWithUrlstring:(NSString *)urlString
                          requestParamets:(NSDictionary *)paramets
                          responseSuccess:(requestSuccess)success
                            responseFaild:(requestFaild)faild
                             requestError:(requestError)error;

//get请求
+ (void)netGetRequestServerWithUrlsting:(NSString *)urlString
                        requestParamets:(NSDictionary *)paramets
                        responseSuccess:(requestSuccess)success
                          responseFaild:(requestFaild)faild
                           requestError:(requestError)error;

//检测网络可用性
+ (BOOL) netWorkReachabilityWithURLString:(NSString *) strUrl;

@end
