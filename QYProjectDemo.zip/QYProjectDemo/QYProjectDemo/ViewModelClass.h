//
//  ViewModelClass.h
//  QYProjectDemo
//
//  Created by qiyun on 15/7/10.
//  Copyright (c) 2015年 com.application.qiyun. All rights reserved.
//

//请求成功
typedef void (^requestSuccess) (id success);
//请求失败
typedef void (^requestFaild) (id faild);
//请求错误（网络异常）
typedef void (^requestError) (id error);


#import <Foundation/Foundation.h>

typedef void (^NetWorkBlock)(BOOL netConnetState);

@interface ViewModelClass : NSObject

@property (strong, nonatomic) requestSuccess success;
@property (strong, nonatomic) requestFaild faild;
@property (strong, nonatomic) requestError error;

//网络状态
- (void)netWorkStatuWithServerConnect:(NetWorkBlock)netConnectBlock
                        withURLString:(NSString *)urlString;

// 传入交互的Block块
- (void)valueBlockReturn:(requestSuccess)success
            requestFaild:(requestFaild)faild
            requestError:(requestError)error;

@end
