//
//  JKRequestClass.m
//  QYProjectDemo
//
//  Created by qiyun on 15/7/17.
//  Copyright (c) 2015年 com.application.qiyun. All rights reserved.
//

#import "JKRequestClass.h"

@implementation JKRequestClass


#define kHostServers @"http://test-jkda.998jk.com/mobile/"

//post请求
+ (void)netPostRequestServerWithUrlstring:(NSString *)urlString
                          requestParamets:(NSDictionary *)paramets
                          responseSuccess:(requestSuccess)success
                            responseFaild:(requestFaild)faild
                             requestError:(requestError)error{

    //添加cookie值
    NSHTTPCookieStorage *cookieJar = [NSHTTPCookieStorage sharedHTTPCookieStorage];

    [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookies:[cookieJar cookies]
                                                       forURL:[NSURL URLWithString:kHostServers]
                                              mainDocumentURL:[[NSURL URLWithString:kHostServers] baseURL]];

    AFHTTPSessionManager  *manager = [[AFHTTPSessionManager alloc] initWithBaseURL:[NSURL URLWithString:kHostServers]];

    manager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];

    [manager POST:urlString parameters:paramets
          success:^(NSURLSessionDataTask *task, id responseObject) {

              NSDictionary  *retDict = (NSDictionary *)responseObject;

              success(retDict);

          } failure:^(NSURLSessionDataTask *task, NSError *error) {

              faild([error userInfo]);
          }];
}

//get请求
+ (void)netGetRequestServerWithUrlsting:(NSString *)urlString
                        requestParamets:(NSDictionary *)paramets
                        responseSuccess:(requestSuccess)success
                          responseFaild:(requestFaild)faild
                           requestError:(requestError)error{

    //添加cookie值
    NSHTTPCookieStorage *cookieJar = [NSHTTPCookieStorage sharedHTTPCookieStorage];

    [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookies:[cookieJar cookies]
                                                       forURL:[NSURL URLWithString:kHostServers]
                                              mainDocumentURL:[[NSURL URLWithString:kHostServers] baseURL]];

    AFHTTPSessionManager  *manager = [[AFHTTPSessionManager alloc] initWithBaseURL:[NSURL URLWithString:kHostServers]];

    manager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];

    [manager GET:urlString parameters:paramets
         success:^(NSURLSessionDataTask *task, id responseObject) {

             NSDictionary  *retDict = (NSDictionary *)responseObject;
             success(retDict);

         } failure:^(NSURLSessionDataTask *task, NSError *error) {

             faild([error userInfo]);
         }];
}

// 监测网络的可链接性
+ (BOOL) netWorkReachabilityWithURLString:(NSString *) strUrl
{
    __block BOOL netState = NO;

    NSURL *baseURL = [NSURL URLWithString:strUrl];

    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:baseURL];

    NSOperationQueue *operationQueue = manager.operationQueue;

    [manager.reachabilityManager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {

            case AFNetworkReachabilityStatusReachableViaWWAN:
            case AFNetworkReachabilityStatusReachableViaWiFi:
                [operationQueue setSuspended:NO];
                netState = YES;
                break;
            case AFNetworkReachabilityStatusNotReachable:
                netState = NO;
            default:
                [operationQueue setSuspended:YES];
                break;
        }
    }];
    
    [manager.reachabilityManager startMonitoring];
    
    return netState;
}

@end
