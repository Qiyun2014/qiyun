//
//  JKColor+RGB.h
//  QYProjectDemo
//
//  Created by qiyun on 15/7/16.
//  Copyright (c) 2015年 com.application.qiyun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (JKColor)

//背景色
+ (UIColor *)colorWithBacgroundColor;

//文本色
+ (UIColor *)colorWithTextColor;



@end

