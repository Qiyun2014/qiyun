//
//  ViewControllerTableViewCell.m
//  QYProjectDemo
//
//  Created by qiyun on 15/7/15.
//  Copyright (c) 2015年 com.application.qiyun. All rights reserved.
//

#import "ViewControllerTableViewCell.h"
#import "JKColor+RGB.h"

@implementation ViewControllerTableViewCell

- (void)setElementsDataFromModel:(ViewControllerModel *)model{

    [self._unBtton setTitle:model._userName forState:UIControlStateNormal];

    self.hcLabel.text = model._healthAccount;
    self.hcLabel.textColor = [UIColor colorWithTextColor];
}

- (void)awakeFromNib {
    // Initialization code

    NSLog(@"~~~~~~~~~");
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
