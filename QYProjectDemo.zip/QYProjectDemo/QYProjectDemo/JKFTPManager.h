//
//  JKFTPManager.h
//  QYProjectDemo
//
//  Created by qiyun on 15/7/16.
//  Copyright (c) 2015年 com.application.qiyun. All rights reserved.
//

#import <Foundation/Foundation.h>
#include <CFNetwork/CFNetwork.h>

enum{

    KSendBufferSize = 32768
};

//ftp代理协议
@protocol FTPManagerDelegate <NSObject>

//ftp上传
- (void)ftpUnloadFinishedWithSuccess:(BOOL)success;

//ftp下载
- (void)ftpDownloadFinishedWithSuccess:(BOOL)success;

//ftp建立目录
- (void)directoryListingFinishedWithSuccess:(NSArray *)arr;

//ftp错误
- (void)ftpError:(NSString *)error;

@end

@interface JKFTPManager : NSObject

//初始化服务
- (id)initWithServer:(NSString *)server
                user:(NSString *)userName
            password:(NSString *)passWord;

//下载远程文件
- (void)downloadRemoteFile:(NSString *)fileName
             localFileName:(NSString *)localName;

//上传文件
- (void)uploadFileWithFilePath:(NSString *)filePath;

//创建远程目录
- (void)createRemoteDirectory:(NSString *)directoryName;

//远程目录列表
- (void)listRemoteDirectory;

@property (nonatomic,assign) id <FTPManagerDelegate> delegate;


@end
