//
//  ViewControllerModel.h
//  QYProjectDemo
//
//  Created by qiyun on 15/7/10.
//  Copyright (c) 2015年 com.application.qiyun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ViewControllerModel : NSObject

@property (nonatomic,strong) NSString   *_userName;

@property (nonatomic,strong) NSString   *_healthAccount;

@end
