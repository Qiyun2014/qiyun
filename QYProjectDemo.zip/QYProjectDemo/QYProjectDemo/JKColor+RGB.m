//
//  JKColor+RGB.m
//  QYProjectDemo
//
//  Created by qiyun on 15/7/16.
//  Copyright (c) 2015年 com.application.qiyun. All rights reserved.
//

#import "JKColor+RGB.h"

@implementation UIColor (JKColor)

//背景色
+ (UIColor *)colorWithBacgroundColor{

    return [self colorWithRed:1 green:0.9 blue:0.7 alpha:1];
}

//文本色
+ (UIColor *)colorWithTextColor{

    return [self colorWithRed:1 green:0.9 blue:0.7 alpha:1];
}

@end
